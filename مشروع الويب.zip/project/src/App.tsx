import { Mail, Phone, MapPin, Linkedin, Github, Briefcase, GraduationCap, Code, Award, ExternalLink } from 'lucide-react';

function App() {
  return (
    <div className="min-h-screen bg-gradient-to-br from-gray-900 via-gray-800 to-gray-900 text-gray-100">
      <div className="max-w-5xl mx-auto px-6 py-12">
        <header className="mb-16 text-center">
          <div className="mb-6">
            <div className="w-32 h-32 mx-auto mb-6 rounded-full bg-gradient-to-br from-cyan-500 to-blue-600 flex items-center justify-center text-4xl font-bold text-white shadow-2xl">
              JD
            </div>
            <h1 className="text-5xl font-bold mb-3 bg-gradient-to-r from-cyan-400 to-blue-500 bg-clip-text text-transparent">
              John Doe
            </h1>
            <p className="text-2xl text-gray-300 mb-6">Senior Full Stack Developer</p>
            <div className="flex flex-wrap justify-center gap-4 text-sm text-gray-400">
              <a href="mailto:john.doe@email.com" className="flex items-center gap-2 hover:text-cyan-400 transition-colors">
                <Mail size={16} />
                john.doe@email.com
              </a>
              <a href="tel:+1234567890" className="flex items-center gap-2 hover:text-cyan-400 transition-colors">
                <Phone size={16} />
                +1 (234) 567-890
              </a>
              <span className="flex items-center gap-2">
                <MapPin size={16} />
                San Francisco, CA
              </span>
            </div>
            <div className="flex justify-center gap-4 mt-6">
              <a href="https://linkedin.com" target="_blank" rel="noopener noreferrer" className="p-3 bg-gray-800 rounded-full hover:bg-cyan-600 transition-all hover:scale-110">
                <Linkedin size={20} />
              </a>
              <a href="https://github.com" target="_blank" rel="noopener noreferrer" className="p-3 bg-gray-800 rounded-full hover:bg-cyan-600 transition-all hover:scale-110">
                <Github size={20} />
              </a>
            </div>
          </div>
        </header>

        <section className="mb-12">
          <h2 className="text-3xl font-bold mb-6 flex items-center gap-3">
            <div className="w-10 h-10 bg-cyan-600 rounded-lg flex items-center justify-center">
              <Briefcase size={20} />
            </div>
            About Me
          </h2>
          <div className="bg-gray-800/50 backdrop-blur rounded-2xl p-8 border border-gray-700 shadow-xl">
            <p className="text-gray-300 leading-relaxed text-lg">
              Passionate full stack developer with 8+ years of experience building scalable web applications.
              Specialized in React, Node.js, and cloud technologies. I thrive on solving complex problems and
              creating elegant solutions that deliver real value to users. Always eager to learn new technologies
              and share knowledge with the development community.
            </p>
          </div>
        </section>

        <section className="mb-12">
          <h2 className="text-3xl font-bold mb-6 flex items-center gap-3">
            <div className="w-10 h-10 bg-cyan-600 rounded-lg flex items-center justify-center">
              <Briefcase size={20} />
            </div>
            Experience
          </h2>
          <div className="space-y-6">
            <div className="bg-gray-800/50 backdrop-blur rounded-2xl p-8 border border-gray-700 shadow-xl hover:border-cyan-600 transition-all">
              <div className="flex justify-between items-start mb-4">
                <div>
                  <h3 className="text-2xl font-semibold text-cyan-400">Senior Full Stack Developer</h3>
                  <p className="text-gray-400 text-lg">Tech Innovations Inc.</p>
                </div>
                <span className="text-gray-400 text-sm bg-gray-700 px-4 py-2 rounded-full">2021 - Present</span>
              </div>
              <ul className="space-y-2 text-gray-300 list-disc list-inside">
                <li>Led development of microservices architecture serving 2M+ users</li>
                <li>Reduced application load time by 60% through optimization techniques</li>
                <li>Mentored team of 5 junior developers and conducted code reviews</li>
                <li>Implemented CI/CD pipelines reducing deployment time by 75%</li>
              </ul>
            </div>

            <div className="bg-gray-800/50 backdrop-blur rounded-2xl p-8 border border-gray-700 shadow-xl hover:border-cyan-600 transition-all">
              <div className="flex justify-between items-start mb-4">
                <div>
                  <h3 className="text-2xl font-semibold text-cyan-400">Full Stack Developer</h3>
                  <p className="text-gray-400 text-lg">Digital Solutions Co.</p>
                </div>
                <span className="text-gray-400 text-sm bg-gray-700 px-4 py-2 rounded-full">2018 - 2021</span>
              </div>
              <ul className="space-y-2 text-gray-300 list-disc list-inside">
                <li>Developed and maintained 10+ client-facing web applications</li>
                <li>Collaborated with UX team to implement responsive designs</li>
                <li>Integrated third-party APIs and payment gateways</li>
                <li>Improved test coverage from 40% to 85%</li>
              </ul>
            </div>

            <div className="bg-gray-800/50 backdrop-blur rounded-2xl p-8 border border-gray-700 shadow-xl hover:border-cyan-600 transition-all">
              <div className="flex justify-between items-start mb-4">
                <div>
                  <h3 className="text-2xl font-semibold text-cyan-400">Junior Developer</h3>
                  <p className="text-gray-400 text-lg">StartUp Labs</p>
                </div>
                <span className="text-gray-400 text-sm bg-gray-700 px-4 py-2 rounded-full">2016 - 2018</span>
              </div>
              <ul className="space-y-2 text-gray-300 list-disc list-inside">
                <li>Built responsive front-end interfaces using React and Vue.js</li>
                <li>Contributed to REST API development using Node.js and Express</li>
                <li>Participated in agile development and daily stand-ups</li>
              </ul>
            </div>
          </div>
        </section>

        <section className="mb-12">
          <h2 className="text-3xl font-bold mb-6 flex items-center gap-3">
            <div className="w-10 h-10 bg-cyan-600 rounded-lg flex items-center justify-center">
              <GraduationCap size={20} />
            </div>
            Education
          </h2>
          <div className="bg-gray-800/50 backdrop-blur rounded-2xl p-8 border border-gray-700 shadow-xl">
            <div className="flex justify-between items-start">
              <div>
                <h3 className="text-2xl font-semibold text-cyan-400">Bachelor of Science in Computer Science</h3>
                <p className="text-gray-400 text-lg mt-2">University of Technology</p>
                <p className="text-gray-500 mt-2">GPA: 3.8/4.0</p>
              </div>
              <span className="text-gray-400 text-sm bg-gray-700 px-4 py-2 rounded-full">2012 - 2016</span>
            </div>
          </div>
        </section>

        <section className="mb-12">
          <h2 className="text-3xl font-bold mb-6 flex items-center gap-3">
            <div className="w-10 h-10 bg-cyan-600 rounded-lg flex items-center justify-center">
              <Code size={20} />
            </div>
            Skills
          </h2>
          <div className="bg-gray-800/50 backdrop-blur rounded-2xl p-8 border border-gray-700 shadow-xl">
            <div className="grid md:grid-cols-2 gap-8">
              <div>
                <h3 className="text-xl font-semibold text-cyan-400 mb-4">Frontend</h3>
                <div className="flex flex-wrap gap-2">
                  {['React', 'TypeScript', 'Next.js', 'Tailwind CSS', 'Vue.js', 'Redux', 'HTML5', 'CSS3'].map((skill) => (
                    <span key={skill} className="px-4 py-2 bg-gray-700 rounded-full text-sm hover:bg-cyan-600 transition-colors cursor-default">
                      {skill}
                    </span>
                  ))}
                </div>
              </div>
              <div>
                <h3 className="text-xl font-semibold text-cyan-400 mb-4">Backend</h3>
                <div className="flex flex-wrap gap-2">
                  {['Node.js', 'Express', 'PostgreSQL', 'MongoDB', 'Redis', 'REST APIs', 'GraphQL', 'Supabase'].map((skill) => (
                    <span key={skill} className="px-4 py-2 bg-gray-700 rounded-full text-sm hover:bg-cyan-600 transition-colors cursor-default">
                      {skill}
                    </span>
                  ))}
                </div>
              </div>
              <div>
                <h3 className="text-xl font-semibold text-cyan-400 mb-4">DevOps & Tools</h3>
                <div className="flex flex-wrap gap-2">
                  {['Docker', 'AWS', 'Git', 'CI/CD', 'Linux', 'Nginx', 'Jenkins'].map((skill) => (
                    <span key={skill} className="px-4 py-2 bg-gray-700 rounded-full text-sm hover:bg-cyan-600 transition-colors cursor-default">
                      {skill}
                    </span>
                  ))}
                </div>
              </div>
              <div>
                <h3 className="text-xl font-semibold text-cyan-400 mb-4">Other</h3>
                <div className="flex flex-wrap gap-2">
                  {['Agile', 'Scrum', 'Testing', 'TDD', 'Microservices', 'WebSockets'].map((skill) => (
                    <span key={skill} className="px-4 py-2 bg-gray-700 rounded-full text-sm hover:bg-cyan-600 transition-colors cursor-default">
                      {skill}
                    </span>
                  ))}
                </div>
              </div>
            </div>
          </div>
        </section>

        <section className="mb-12">
          <h2 className="text-3xl font-bold mb-6 flex items-center gap-3">
            <div className="w-10 h-10 bg-cyan-600 rounded-lg flex items-center justify-center">
              <Award size={20} />
            </div>
            Featured Projects
          </h2>
          <div className="grid md:grid-cols-2 gap-6">
            <div className="bg-gray-800/50 backdrop-blur rounded-2xl p-8 border border-gray-700 shadow-xl hover:border-cyan-600 transition-all group">
              <h3 className="text-2xl font-semibold text-cyan-400 mb-3 flex items-center justify-between">
                E-Commerce Platform
                <ExternalLink size={20} className="opacity-0 group-hover:opacity-100 transition-opacity" />
              </h3>
              <p className="text-gray-300 mb-4">
                Full-featured e-commerce platform with payment integration, inventory management, and admin dashboard.
              </p>
              <div className="flex flex-wrap gap-2">
                <span className="px-3 py-1 bg-gray-700 rounded-full text-xs">React</span>
                <span className="px-3 py-1 bg-gray-700 rounded-full text-xs">Node.js</span>
                <span className="px-3 py-1 bg-gray-700 rounded-full text-xs">PostgreSQL</span>
                <span className="px-3 py-1 bg-gray-700 rounded-full text-xs">Stripe</span>
              </div>
            </div>

            <div className="bg-gray-800/50 backdrop-blur rounded-2xl p-8 border border-gray-700 shadow-xl hover:border-cyan-600 transition-all group">
              <h3 className="text-2xl font-semibold text-cyan-400 mb-3 flex items-center justify-between">
                Real-time Chat App
                <ExternalLink size={20} className="opacity-0 group-hover:opacity-100 transition-opacity" />
              </h3>
              <p className="text-gray-300 mb-4">
                WebSocket-based chat application with typing indicators, read receipts, and file sharing capabilities.
              </p>
              <div className="flex flex-wrap gap-2">
                <span className="px-3 py-1 bg-gray-700 rounded-full text-xs">Next.js</span>
                <span className="px-3 py-1 bg-gray-700 rounded-full text-xs">WebSockets</span>
                <span className="px-3 py-1 bg-gray-700 rounded-full text-xs">Redis</span>
                <span className="px-3 py-1 bg-gray-700 rounded-full text-xs">AWS S3</span>
              </div>
            </div>

            <div className="bg-gray-800/50 backdrop-blur rounded-2xl p-8 border border-gray-700 shadow-xl hover:border-cyan-600 transition-all group">
              <h3 className="text-2xl font-semibold text-cyan-400 mb-3 flex items-center justify-between">
                Analytics Dashboard
                <ExternalLink size={20} className="opacity-0 group-hover:opacity-100 transition-opacity" />
              </h3>
              <p className="text-gray-300 mb-4">
                Data visualization dashboard with real-time metrics, custom reports, and exportable charts.
              </p>
              <div className="flex flex-wrap gap-2">
                <span className="px-3 py-1 bg-gray-700 rounded-full text-xs">React</span>
                <span className="px-3 py-1 bg-gray-700 rounded-full text-xs">TypeScript</span>
                <span className="px-3 py-1 bg-gray-700 rounded-full text-xs">D3.js</span>
                <span className="px-3 py-1 bg-gray-700 rounded-full text-xs">Express</span>
              </div>
            </div>

            <div className="bg-gray-800/50 backdrop-blur rounded-2xl p-8 border border-gray-700 shadow-xl hover:border-cyan-600 transition-all group">
              <h3 className="text-2xl font-semibold text-cyan-400 mb-3 flex items-center justify-between">
                Task Management System
                <ExternalLink size={20} className="opacity-0 group-hover:opacity-100 transition-opacity" />
              </h3>
              <p className="text-gray-300 mb-4">
                Collaborative project management tool with drag-and-drop interface, team workspaces, and time tracking.
              </p>
              <div className="flex flex-wrap gap-2">
                <span className="px-3 py-1 bg-gray-700 rounded-full text-xs">Vue.js</span>
                <span className="px-3 py-1 bg-gray-700 rounded-full text-xs">GraphQL</span>
                <span className="px-3 py-1 bg-gray-700 rounded-full text-xs">MongoDB</span>
                <span className="px-3 py-1 bg-gray-700 rounded-full text-xs">Docker</span>
              </div>
            </div>
          </div>
        </section>

        <section className="mb-12">
          <h2 className="text-3xl font-bold mb-6 flex items-center gap-3">
            <div className="w-10 h-10 bg-cyan-600 rounded-lg flex items-center justify-center">
              <Mail size={20} />
            </div>
            Get In Touch
          </h2>
          <div className="bg-gray-800/50 backdrop-blur rounded-2xl p-8 border border-gray-700 shadow-xl text-center">
            <p className="text-gray-300 text-lg mb-6">
              I'm always interested in hearing about new opportunities and exciting projects.
              Feel free to reach out if you'd like to connect!
            </p>
            <a
              href="mailto:john.doe@email.com"
              className="inline-flex items-center gap-2 bg-gradient-to-r from-cyan-600 to-blue-600 px-8 py-4 rounded-full text-white font-semibold hover:from-cyan-500 hover:to-blue-500 transition-all hover:scale-105 shadow-lg"
            >
              <Mail size={20} />
              Send me an email
            </a>
          </div>
        </section>

        <footer className="text-center text-gray-500 text-sm py-8 border-t border-gray-800">
          <p>&copy; 2024 John Doe. All rights reserved.</p>
        </footer>
      </div>
    </div>
  );
}

export default App;
